---
layout: list
title: Cross-Platform
slug: Cross-Platform
menu: true
order: 5
description: >
  One of the focuses of the Bincrafters team is packaging tools for each major platforms in it's native format: DEB and RPM for Linux, MSI and NUPKG for Windows, and Brew Bottles for MAC. 

---
