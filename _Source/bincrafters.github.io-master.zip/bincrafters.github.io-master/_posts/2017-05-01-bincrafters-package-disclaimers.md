---
layout: post
title: 'Bincrafters Packages - Disclaimers'
tags: [Bintray, Conan.io]
---

## Licensing
Currently, Bincrafters is a volunteer group of Open-Source developers creating packages from Open-Source software developed by others.  Bincrafters do not claim to provide any license to any software in any such packages. All matters regarding licenses of software contained in Bincrafters packages are the responsibility of the user of said packages. 

## Warranty, Defect, or Damages
As with most Open-Source software, Bincrafters packages are provided "as is", without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose and noninfringement.  In no event shall the authors or copyright holders be liable for any claim, damages, or other liability, whether in action of contract, tort or otherwise, arising from, out of or in connection with the packages or the use or other dealings in the software. 
